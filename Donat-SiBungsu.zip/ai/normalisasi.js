// Text normalization
