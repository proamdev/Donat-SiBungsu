// Intent rules
