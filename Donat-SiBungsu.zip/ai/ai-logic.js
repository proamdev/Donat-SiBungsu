// AI logic placeholder
